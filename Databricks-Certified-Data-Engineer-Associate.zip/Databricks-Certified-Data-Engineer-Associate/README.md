# Databricks Certified Data Engineer Associate

<img align="left" role="left" src="https://img-c.udemycdn.com/course/240x135/4956262_2022_2.jpg" width="180" alt="Databricks Certified Data Engineer Associate - Preparation" />
This repository contains the resources of the preparation course for Databricks Data Engineer Associate certification exam on Udemy:
<br/>
<a href="https://www.udemy.com/course/databricks-certified-data-engineer-associate/?referralCode=F0FA48E9A0546C975F14" target="_blank">https://www.udemy.com/course/databricks-certified-data-engineer-associate/?referralCode=F0FA48E9A0546C975F14</a>.
<br/>
<br/>


## Practice Exams

<img align="left" role="left" src="https://img-c.udemycdn.com/course/240x135/5005556_5c54.jpg" width="180" alt="Practice Exams: Databricks Certified Data Engineer Associate" />
Practice exams for this certification are available in the following Udemy course:
<br/>
<a href="https://www.udemy.com/course/practice-exams-databricks-certified-data-engineer-associate/?referralCode=9AA679C03D1F51B2C956" target="_blank">https://www.udemy.com/course/practice-exams-databricks-certified-data-engineer-associate/?referralCode=9AA679C03D1F51B2C956</a>.<br/>
